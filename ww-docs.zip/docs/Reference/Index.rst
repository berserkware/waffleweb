=============
API Reference
=============

This part of the documentation cover the code and internals of Waffleweb.


Contents
........
1. `project.py <project.py.rst>`_
2. `app.py <app.py.rst>`_
3. `response.py <response.py.rst>`_
4. `request.py <request.py.rst>`_
5. `static.py <static.py.rst>`_
6. `template.py <template.py.rst>`_
7. `middleware.py <middleware.py.rst>`_
8. `wsgi.py <wsgi.py.rst>`_
9. `datatypes.py <datatypes.py.rst>`_
10. `cookie.py <cookie.py.rst>`_
11. `files.py <files.py.rst>`_
12. `parser.py <parser.py.rst>`_
13. `errorResponses.py <errorResponses.py.rst>`_