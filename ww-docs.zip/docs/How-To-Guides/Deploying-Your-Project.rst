==============================
How-To: Deploying Your Project
==============================

Waffleweb allows you to deploy your project with WSGI. In this How-To guide you will be shown how to deploy your project with `Gunicorn <https://gunicorn.org/>`_.

Installing Gunicorn
-------------------

To install Gunicorn you can use pip.

.. code-block:: bash

	$ pip install gunicorn
	
Getting The WSGI Callable
-------------------------

The WSGI callable is a method of your WaffleProject called "wsgiApplication".

.. code-block:: python

	wsgiApp = yourProject.wsgiApplication
	
Connecting The Callable To Gunicorn
-----------------------------------

Connecting the WSGI callable to Gunicorn is easy.

.. code-block:: bash

	$ gunicorn project:wsgiApp
	
In your terminal you should now see something like this:

.. code-block::

	[2022-07-02 17:34:48 +1200] [18669] [INFO] Starting gunicorn 20.1.0
	[2022-07-02 17:34:48 +1200] [18669] [INFO] Listening at: http://127.0.0.1:8000 (18669)
	[2022-07-02 17:34:48 +1200] [18669] [INFO] Using worker: sync
	[2022-07-02 17:34:48 +1200] [18670] [INFO] Booting worker with pid: 18670

If you go to http://127.0.0.1:8000 you should now see your website working.

For more information on Gunicorn you can go to the `Gunicorn Docs <https://docs.gunicorn.org/en/stable/index.html>`_.