===============
Getting Started
===============

How to get started with Waffleweb.

========
Contents
========
1. `Installation Guide <Installation-Guide.rst>`_
2. `The Basics <Basics.rst>`_